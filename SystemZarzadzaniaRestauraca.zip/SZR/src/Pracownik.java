import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import java.sql.ResultSet;
public class Pracownik {
    private String imie;
    private String nazwisko;
    private double pensja;

    public Pracownik(String imie, String nazwisko, double pensja) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.pensja = pensja;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }

    public void setPensja(double pensja) {
        this.pensja = pensja;
    }


    public String getImie() {
        return imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public double getPensja() {
        return pensja;
    }

    public void wyswietlInformacje() {
        System.out.println("Imię: " + imie + ", Nazwisko: " + nazwisko + ", Pensja: " + pensja);
    }

    public static void dodajPracownikaDoBD(Pracownik pracownik) {
        Connection connection = DBConnection.getConnection();
        String sql = "INSERT INTO pracownicy (imie, nazwisko, pensja) VALUES (?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, pracownik.getImie());
            statement.setString(2, pracownik.getNazwisko());
            statement.setDouble(3, pracownik.getPensja());

            statement.executeUpdate();
            System.out.println("Pracownik został dodany do bazy danych.");
        } catch (SQLException e) {
            System.err.println("Błąd podczas dodawania pracownika do bazy danych: " + e.getMessage());
        }
    }

    public static Pracownik dodajPracownika(Scanner scanner) {
        System.out.println("\nDodawanie pracownika:");
        System.out.print("Imię: ");
        String imie = scanner.next();

        System.out.print("Nazwisko: ");
        String nazwisko = scanner.next();

        System.out.print("Pensja: ");
        double pensja = scanner.nextDouble();
        scanner.nextLine();

        Pracownik pracownik = new Pracownik(imie, nazwisko, pensja);
        dodajPracownikaDoBD(pracownik);
        return pracownik;
    }

    public static void wyswietlPracownikow() {
        Connection connection = DBConnection.getConnection();

        // Sprawdzenie, czy połączenie jest prawidłowe
        if (connection == null) {
            System.out.println("Brak połączenia z bazą danych.");
            return;
        }

        String sql = "SELECT * FROM pracownicy";

        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            // Zmienna flagowa do sprawdzenia, czy w ogóle są dane
            boolean hasResults = resultSet.next();

            if (!hasResults) {
                System.out.println("\nBrak pracowników w systemie.");
            } else {
                System.out.println("\nLista pracowników:");
                do {
                    String imie = resultSet.getString("imie");
                    String nazwisko = resultSet.getString("nazwisko");
                    double pensja = resultSet.getDouble("pensja");

                    System.out.println("Imię: " + imie + ", Nazwisko: " + nazwisko + ", Pensja: " + pensja);
                    System.out.println("------------------");
                } while (resultSet.next());
            }
        } catch (SQLException e) {
            System.err.println("Błąd podczas pobierania danych pracowników z bazy danych: " + e.getMessage());
        }
    }
}
