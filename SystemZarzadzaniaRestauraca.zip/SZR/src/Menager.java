import java.util.Scanner;
public class Menager extends Pracownik {
    private String dzial;

    public Menager(String imie, String nazwisko, double pensja, String dzial) {
        super(imie, nazwisko, pensja);
        this.dzial = dzial;
    }

    public String getDzial() {
        return dzial;
    }

    public void setDzial(String dzial) {
        this.dzial = dzial;
    }

    @Override
    public void wyswietlInformacje() {
        super.wyswietlInformacje();
        System.out.println("Dział: " + dzial);
    }

    public static Menager dodajMenagera(Scanner scanner) {
        System.out.println("\nDodawanie menadżera:");
        System.out.print("Imię: ");
        String imie = scanner.next();

        System.out.print("Nazwisko: ");
        String nazwisko = scanner.next();

        System.out.print("Pensja: ");
        double pensja = scanner.nextDouble();
        scanner.nextLine();

        System.out.print("Dział: ");
        String dzial = scanner.nextLine();

        System.out.println("Dodano menadżera: " + imie + " " + nazwisko);
        return new Menager(imie, nazwisko, pensja, dzial);
    }
}