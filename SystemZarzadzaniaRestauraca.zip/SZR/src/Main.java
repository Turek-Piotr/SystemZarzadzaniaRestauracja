import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.sql.Connection;

public class Main {
    private static final List<Pracownik> pracownicy = new ArrayList<>(); // Lista pracowników

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Restaurant restaurant = new Restaurant();
        Connection connection = DBConnection.getConnection(); // Połączenie z bazą danych

        int choice;
        do {
            System.out.println("\nMenu restauracji:");
            System.out.println("0. Wyjdź");
            System.out.println("1. Dodaj stolik");
            System.out.println("2. Zarezerwuj stolik");
            System.out.println("3. Wyświetl wszystkie stoliki");
            System.out.println("4. Zmień parametry stolika");
            System.out.println("5. Dodaj pracownika");
            System.out.println("6. Dodaj menadżera");
            System.out.println("7. Wyświetl wszystkich pracowników");
            System.out.print("Wybierz opcję: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 0:
                    System.out.println("Do widzenia!");
                    DBConnection.closeConnection();
                    break;
                case 1:
                    // Dodaj stolik
                    System.out.print("Podaj numer stolika: ");
                    int number = scanner.nextInt();
                    System.out.print("Podaj liczbę miejsc: ");
                    int seats = scanner.nextInt();
                    System.out.print("Podaj status stolika: ");
                    scanner.nextLine();
                    String status = scanner.nextLine();
                    Table newTable = new Table(number, seats, status);
                    restaurant.addTable(newTable);
                    break;
                case 2:
                    // Zarezerwuj stolik
                    System.out.print("Podaj numer stolika do rezerwacji: ");
                    int tableNumber = scanner.nextInt();
                    ReservationService reservationService = new ReservationService(scanner, restaurant);
                    reservationService.reserveTable(tableNumber, restaurant);
                    break;
                case 3:
                    // Wyświetl wszystkie stoliki
                    restaurant.displayAllTables();
                    break;
                case 4:
                    // Zmień parametry stolika
                    System.out.print("Podaj numer stolika, którego parametry chcesz zmienić: ");
                    int tableNumberToChange = scanner.nextInt();
                    System.out.print("Podaj nową liczbę miejsc: ");
                    int newSeats = scanner.nextInt();
                    System.out.print("Podaj nowy status stolika: ");
                    scanner.nextLine();
                    String newStatus = scanner.nextLine();
                    restaurant.changeTableParameters(tableNumberToChange, newSeats, newStatus);
                    break;
                case 5:
                    // Dodaj pracownika
                    Pracownik nowyPracownik = Pracownik.dodajPracownika(scanner);
                    pracownicy.add(nowyPracownik);
                    break;
                case 6:
                    // Dodaj menadżera
                    Menager nowyMenager = Menager.dodajMenagera(scanner);
                    pracownicy.add(nowyMenager);
                    break;
                case 7:
                    // Wyświetl wszystkich pracowników
                    Pracownik.wyswietlPracownikow();
                    break;
                default:
                    System.out.println("Niepoprawny wybór. Spróbuj ponownie.");
            }
        } while (choice != 0);

        scanner.close();
    }




}