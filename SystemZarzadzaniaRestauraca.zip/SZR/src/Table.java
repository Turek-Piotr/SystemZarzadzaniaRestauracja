class Table {
    private int number;
    private int seats;
    private String status;
    private String reservedBy;

    public Table(int number, int seats, String status) {
        this.number = number;
        this.seats = seats;
        this.status = status;
        this.reservedBy = "Brak";
    }

    public int getNumber() {
        return this.number;
    }

    public int getSeats() {
        return this.seats;
    }

    public String getStatus() {
        return this.status;
    }

    public String getReservedBy() {
        return this.reservedBy;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setReservedBy(String reservedBy) {
        this.reservedBy = reservedBy;
    }
}
