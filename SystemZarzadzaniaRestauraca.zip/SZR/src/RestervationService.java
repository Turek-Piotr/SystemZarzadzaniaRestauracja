import java.util.Scanner;

class ReservationService {
    private final Scanner scanner;

    public ReservationService(Scanner scanner, Restaurant restaurant) {
        this.scanner = scanner;
    }

    public void reserveTable(int tableNumber, Restaurant restaurant) {
        boolean found = false;
        for (Table table : restaurant.getTables()) {
            if (table.getNumber() == tableNumber) {
                found = true;
                if (!table.getStatus().equalsIgnoreCase("Zarezerwowany")) {
                    table.setStatus("Zarezerwowany");
                    System.out.println("Podaj swoje imię:");
                    String firstName = this.scanner.next();
                    System.out.println("Podaj swoje nazwisko:");
                    String lastName = this.scanner.next();
                    System.out.println("Podaj numer telefonu:");
                    String phoneNumber = this.scanner.next();
                    table.setReservedBy(firstName + " " + lastName + ", tel: " + phoneNumber);
                    System.out.println("Stolik o numerze " + tableNumber + " został zarezerwowany na " + firstName + " " + lastName + ".");
                } else {
                    System.out.println("Stolik o numerze " + tableNumber + " jest już zarezerwowany.");
                }
                break;
            }
        }

        if (!found) {
            System.out.println("Nie znaleziono stolika o podanym numerze.");
        }
    }
}
