import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Restaurant {
    Scanner scanner;
    private final List<Table> tables;

    Restaurant() {
        this.scanner = new Scanner(System.in);
        this.tables = new ArrayList();
    }

    public void addTable(Table table) {
        this.tables.add(table);
    }

    public List<Table> getTables() {
        return this.tables;
    }

    public void displayAllTables() {
        if (tables.isEmpty()) {
            System.out.println("Brak stolików.");
        } else {
            int tableNumber = 1;
            for (Table table : tables) {
                System.out.println("\nStolik " + tableNumber + ":");
                System.out.println("Numer stolika: " + table.getNumber() + "\nLiczba miejsc: " + table.getSeats() + "\nStatus stolika: " + table.getStatus() + "\n");
                tableNumber++;
            }
        }
    }

    public void changeTableParameters(int tableNumber, int newSeats, String newStatus) {
        boolean found = false;
        for (Table table : tables) {
            if (table.getNumber() == tableNumber) {
                table.setSeats(newSeats);
                table.setStatus(newStatus);
                found = true;
                System.out.println("Parametry stolika o numerze " + tableNumber + " zostały zmienione.");
                break;
            }
        }
        if (!found) {
            System.out.println("Nie znaleziono stolika o podanym numerze.");
        }
    }
}

